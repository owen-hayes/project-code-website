import React, { useEffect, useState } from 'react';

import './App.css';
import HomeBar from './components/navbar/HomeBar';

import {
  CssBaseline,
  createTheme,
  ThemeProvider,
  responsiveFontSizes,
  StyledEngineProvider,
} from '@mui/material';
import './font-import.css';
import { BrowserRouter as Router, Route, Routes } from 'react-router-dom';
import HomePage from './components/routes/HomePage';
import Projects from './components/routes/Projects';
import Expenses from './components/routes/expenses';
import NewProjects from './components/routes/NewProjects';
import { UserContext } from './components/context/user-context';

function App() {
  const [darkState, setDarkState] = useState(false);
  const palletType = darkState ? 'dark' : 'light';
  // const mainPrimaryColor = darkState ? '#262626' : '#fc4e47';
  const mainPrimaryColor = darkState ? '#fc4e47' : '#fc4e47';
  // const mainSecondaryColor = darkState ? '#fc4e47' : '#fc4e47';
  const mainSecondaryColor = darkState ? '#fc4e47' : '#f5f5f5';
  const mainBarColor = darkState ? '#4d4d4d' : '#ebebeb';
  let darkTheme = createTheme({
    typography: {
      // htmlFontSize: '14',
      fontFamily: '"Raleway", "Helvetica"',
      h1: {
        fontWeight: 'bold',
      },
    },
    palette: {
      mode: palletType,
      primary: { main: mainPrimaryColor },
      secondary: { main: mainSecondaryColor },
      barBg: { main: mainBarColor, black: '#333333', white: '#f5f5f5' },
    },
  });
  darkTheme = responsiveFontSizes(darkTheme);
  const handleThemeChange = () => {
    setDarkState(!darkState);
  };

  const [user, setUser] = useState();

  function setAndSaveUser(user) {
    setUser(user);
    localStorage.setItem('user', JSON.stringify(user));
  }

  // Check if user is logged in
  useEffect(() => {
    const loggedInUser = localStorage.getItem('user');
    console.log('loggedInUser');
    console.log(loggedInUser);
    if (loggedInUser != 'undefined') {
      const foundUser = JSON.parse(loggedInUser);
      setUser(foundUser);
    }
  }, []);

  return (
    <StyledEngineProvider injectFirst>
      <ThemeProvider theme={darkTheme}>
        <UserContext.Provider value={{ user: user, setUser: setAndSaveUser }}>
          <CssBaseline />
          {/* <div className='App'> */}
          <Router>
            <HomeBar
              handleThemeChange={handleThemeChange}
              darkState={darkState}
            />
            <Routes>
              <Route path='/' element={<HomePage />} />
              <Route path='/projects' element={<Projects />} />
              <Route path='/expenses' element={<Expenses />} />
              <Route path='/newprojects' element={<NewProjects />} />
            </Routes>
          </Router>
        </UserContext.Provider>
        {/* </div> */}
      </ThemeProvider>
    </StyledEngineProvider>
  );
}

export default App;
