const { initializeApp } = require('firebase-admin/app');

const { getAuth } = require('firebase-admin/auth');

const app = initializeApp();

const auth = getAuth();

function getUserCustomClaims(uid) {
  auth.getUser(uid).then((userRecord) => {
    return userRecord.customClaims;
  });
}

console.log(getUserCustomClaims('j2QWiUyaDFYHD37FUiMGBUrv5Bm1'));

getAuth()
  .setCustomUserClaims('j2QWiUyaDFYHD37FUiMGBUrv5Bm1', { admin: true })
  .then((response) => {
    console.log(response);
  });

console.log(getUserCustomClaims('j2QWiUyaDFYHD37FUiMGBUrv5Bm1'));
