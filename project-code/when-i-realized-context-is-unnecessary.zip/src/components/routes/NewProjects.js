import {
  Button,
  Card,
  CardActions,
  CardContent,
  CardMedia,
  Container,
  Grid,
  Typography,
} from '@mui/material';
import React, { useEffect, useState } from 'react';
import OpenInNewIcon from '@mui/icons-material/OpenInNew';
import GitHubIcon from '@mui/icons-material/GitHub';
import { initializeApp } from 'firebase/app';
import { getDatabase, ref, child, get } from 'firebase/database';
import ProjectCard from './ProjectCard';

const firebaseConfig = {
  apiKey: 'AIzaSyBod5foZiSARwnSVO0PtIemHuUWviZCSy4',
  authDomain: 'first-firebase-cli.firebaseapp.com',
  projectId: 'first-firebase-cli',
  storageBucket: 'first-firebase-cli.appspot.com',
  messagingSenderId: '781204296713',
  appId: '1:781204296713:web:5193bfc3a720755d5dd4d8',
};

// Initialize Firebase
initializeApp(firebaseConfig);

export default function NewProjects() {
  let [projects, setProjects] = useState([]);

  // Get projects from database
  useEffect(() => {
    const dbRef = ref(getDatabase());
    get(child(dbRef, 'projects'))
      .then((snapshot) => {
        if (snapshot.exists()) {
          console.log(snapshot.val());
          setProjects(snapshot.val());
        } else {
          console.log('No data available');
        }
      })
      .catch((error) => {
        console.error(error);
      });
  }, []);

  return (
    <Container sx={{ pt: 2 }}>
      <Typography variant='h3' fontWeight='bold' textAlign='center' mb={2}>
        Projects Gallery
      </Typography>
      <Typography>{projects.length}</Typography>
      <Grid container spacing={2}>
        {/* Map all projects to a grid item with a ProjectCard inside */}
        {projects.map((project, idx) => (
          <Grid item xs={12} sm={6} md={4} key={idx}>
            <ProjectCard {...project} />
          </Grid>
        ))}
        <Grid item xs={12} sm={6} md={4}>
          <ProjectCard
            title='Test Project'
            // imageURL='asdf'
            contributors={['asdf', 'l', 'skaljfs  oiw']}
            // projectLink={'undefineasldd'}
            description='asodm kdjfaoksdjfwaie ofaisjfl'
          />
        </Grid>
        <Grid item xs={12} sm={6} md={4}>
          <Card>
            <CardMedia
              component='img'
              image='./Images/Covid-Data-Image(12-12-2020)(SAMPLE).png'
              alt='Covid-19 hotspots around Illinois'
            />
            <CardContent>
              <Typography variant='h4' fontWeight='bold'>
                Visualization of Covid Data across Illinois Counties
              </Typography>
              <Typography variant='h6'>
                Jimmy Berg, Gabe Grais, and Kai Loh
              </Typography>
              <Typography fontStyle='italic'>Led by Manager</Typography>
              <Typography paragraph mt={2}>
                A flask application that takes in a date and displays covid data
                across Illinois Counties at that date. Clicking on a county
                gives a graph of confirmed covid cases over the year.
              </Typography>
              <Typography fontStyle='italic'>Published on 7/20/21</Typography>
            </CardContent>
            <CardActions>
              <Button
                // sx={{ width: '50%' }}
                endIcon={<OpenInNewIcon />}
                href='https://projectcode-coviddata.herokuapp.com/'
                target='_blank'
                variant='outlined'
              >
                View Project
              </Button>
              <Button
                // sx={{ width: '50%' }}
                endIcon={<GitHubIcon />}
                href='https://projectcode-coviddata.herokuapp.com/'
                target='_blank'
                variant='outlined'
              >
                Source Code
              </Button>
            </CardActions>
          </Card>
        </Grid>
        {/* <Grid item xs={12} md={4}>
          <Paper
            sx={{ p: 2 }}
            // className={`${classes.paper} ${classes.leftAlign}`}
            // sx={{ bgcolor: 'red' }}
          >
            <img
              src='./Images/Covid-Data-Image(12-12-2020)(SAMPLE).png'
              width='100%'
              alt='Heatmap of Covid Infections in Illinois'
            />
            <Typography variant='h5' fontWeight='bold'>
              Visualization of Covid Data across Illinois Counties
            </Typography>
            <Typography>Jimmy Berg, Gabe Grais, and Kai Loh</Typography>
            <Typography fontStyle='italic'>Published on 7/20/21</Typography>
            <Typography>
              {' '}
              A flask application that takes in a date and displays covid data
              across Illinois Counties at that date. Clicking on a county gives
              a graph of confirmed covid cases over the year.
            </Typography>
            <Box fontWeight='fontWeightBold'>
              <a
                id='Data-Vis-Heroku-1'
                title='Go to Heroku Container'
                href='https://projectcode-coviddata.herokuapp.com/'
              >
                {' '}
                Click here to view
              </a>
            </Box>
          </Paper>
        </Grid> */}
      </Grid>
    </Container>
  );
}
