import React from 'react';

export default function Expenses() {
  return (
    <main style={{ padding: '1rem 0' }}>
      <h2 style={{ textAlign: 'center' }}>Expenses</h2>
    </main>
  );
}
