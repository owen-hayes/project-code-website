import {
  Button,
  Card,
  CardActions,
  CardContent,
  CardMedia,
  Skeleton,
  // Container,
  // Skeleton,
  Typography,
} from '@mui/material';
import React, { useEffect, useState } from 'react';
import PropTypes from 'prop-types';
import OpenInNewIcon from '@mui/icons-material/OpenInNew';
import GitHubIcon from '@mui/icons-material/GitHub';
import { getStorage, ref, getDownloadURL } from 'firebase/storage';
// import { useImage } from 'react-image';
import { Img } from 'react-image';

/**
 * Convert an array of items into an English list of items.
 * @param {array} items An array of contributors to join with commas
 * @returns A natural language string of items/people (e.g., "Robert Jones, Barack Obama, and Harriet Tubman")
 */
function arrayToEnglishList(items) {
  if (!items) {
    return '';
  }
  let englishList = '';
  switch (items.length) {
    case 1:
      // If only one item, return it
      englishList = items[0];
      break;
    case 2:
      // If only two items, return them with the word 'and' in between
      englishList = items[0] + ' and ' + items[1];
      break;
    default:
      // If 3+ items, return something like: "John Doe, Shriya Patel, and Sam Patterson"
      for (let itemIdx = 0; itemIdx < items.length - 1; itemIdx++) {
        const personName = items[itemIdx];
        englishList = englishList + personName + ', ';
      }
      englishList = englishList + 'and ' + items[items.length - 1];
      break;
  }
  return englishList;
}

function ProjectImage(props) {
  // const { src } = useImage({
  //   srcList: 'https://www.example.com/foo.jpg',
  //   fallback: <Skeleton variant='rectangular' width='100%' height={200} />,
  // });
  return (
    <Img
      src={props.imageURL}
      width='100%'
      loader={
        <Skeleton
          variant='rectangular'
          animation='wave'
          width='100%'
          height={200}
        />
      }
    />
  );
}

ProjectImage.propTypes = {
  imageURL: PropTypes.string,
};

function ProjectCard(props) {
  const [imageURL, setImageURL] = useState(undefined);
  const [imageLoaded, setImageLoaded] = useState(false);

  useEffect(() => {
    if (props.imageName === undefined) return;
    const storage = getStorage();
    getDownloadURL(ref(storage, `/${props.imageName}`))
      .then((url) => {
        // Or inserted into an <img> element
        // const img = document.getElementById('myimg');
        // img.setAttribute('src', url);
        console.log(url);
        setImageURL(url);
      })
      .catch((error) => {
        // Handle any errors
        console.log(error);
      });
  }, []);

  return (
    <>
      {imageLoaded || !props.imageName ? ( // (props.imageName && imageURL) || !props.imageName ? (
        <Card>
          <CardMedia component='img' src={imageURL}>
            {/* <img src={imageURL} width='100%' /> */}
            {/* <ProjectImage imageURL={imageURL} /> */}
          </CardMedia>
          <CardContent>
            <Typography variant='h4' fontWeight='bold'>
              {props.title}
            </Typography>
            <Typography variant='h6'>
              {arrayToEnglishList(props.contributors)}
            </Typography>
            <Typography fontStyle='italic'>Led by {props.manager}</Typography>
            <Typography paragraph mt={2}>
              {props.description}
            </Typography>
            <Typography fontStyle='italic'>
              Published on{' '}
              {new Date(props.publishedDate).toLocaleString(
                navigator.language,
                {
                  dateStyle: 'short',
                }
              )}
            </Typography>
          </CardContent>
          <CardActions>
            {props.projectLink && (
              <Button
                sx={{ width: '100%' }}
                endIcon={<OpenInNewIcon />}
                href={props.projectLink}
                target='_blank'
                variant='outlined'
              >
                View Project
              </Button>
            )}
            {props.sourceCodeLink && (
              <Button
                sx={{ width: '100%' }}
                endIcon={<GitHubIcon />}
                href='https://projectcode-coviddata.herokuapp.com/'
                target='_blank'
                variant='outlined'
              >
                Source Code
              </Button>
            )}
          </CardActions>
        </Card>
      ) : (
        <Card>
          <CardMedia component='div'>
            <Skeleton variant='rectangular' animation='wave' height={200} />
            <img
              src={imageURL}
              onLoad={() => {
                setImageLoaded(true);
              }}
            />
          </CardMedia>
          <CardContent>
            <Skeleton variant='h4' animation='wave' sx={{ mb: 2 }} />
            <Skeleton variant='h6' animation='wave' sx={{ mb: 2 }} />
            <Skeleton variant='subtitle' animation='wave' sx={{ mb: 2 }} />
            <Skeleton variant='body1' animation='wave' sx={{ mb: 2 }} />
          </CardContent>
        </Card>
      )}
    </>
  );
}

ProjectCard.propTypes = {
  imageName: PropTypes.string,
  title: PropTypes.string.isRequired,
  contributors: PropTypes.arrayOf(PropTypes.string).isRequired,
  description: PropTypes.string.isRequired,
  manager: PropTypes.string.isRequired,
  projectLink: PropTypes.string,
  publishedDate: PropTypes.string,
  sourceCodeLink: PropTypes.string,
};

export default ProjectCard;
