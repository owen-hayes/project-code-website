import React, { useContext } from 'react';
import { PropTypes } from 'prop-types';
import { Button } from '@mui/material';

import { initializeApp } from 'firebase/app';
import {
  getAuth,
  signInWithPopup,
  signOut,
  GoogleAuthProvider,
} from 'firebase/auth';
import { UserContext } from '../context/user-context';

const firebaseConfig = {
  apiKey: 'AIzaSyBod5foZiSARwnSVO0PtIemHuUWviZCSy4',
  authDomain: 'first-firebase-cli.firebaseapp.com',
  projectId: 'first-firebase-cli',
  storageBucket: 'first-firebase-cli.appspot.com',
  messagingSenderId: '781204296713',
  appId: '1:781204296713:web:5193bfc3a720755d5dd4d8',
};

// Initialize Firebase
initializeApp(firebaseConfig);
const auth = getAuth();
const provider = new GoogleAuthProvider();

function LoginButton(props) {
  const userContext = useContext(UserContext);

  return (
    <Button
      variant='contained'
      onClick={() => {
        if (userContext.user) {
          signOut(auth).then((result) => {
            console.log(result);
            userContext.setUser(undefined);
            props.handleSnackbarOpen();
          });
          return;
        }
        signInWithPopup(auth, provider)
          .then((result) => {
            // This gives you a Google Access Token. You can use it to access the Google API.
            const credential = GoogleAuthProvider.credentialFromResult(result);
            const token = credential.accessToken;
            // The signed-in user info.
            const signedInUser = result.user;
            // ...
            console.log(credential);
            console.log(token);
            console.log(signedInUser);

            console.log(result);
            props.handleSnackbarOpen();
            userContext.setUser(signedInUser);
            getAuth()
              .currentUser.getIdTokenResult()
              .then((idTokenResult) => {
                // Confirm the user is an Admin.
                if (idTokenResult.claims.admin) {
                  // Show admin UI.
                  // showAdminUI();
                  console.log('admin');
                } else {
                  // Show regular user UI.
                  // showRegularUI();
                  console.log('not admin');
                }
              })
              .catch((error) => {
                console.log(error);
              });

            // console.log(auth.currentUser.getIdToken(true));
          })
          .catch((error) => {
            // // Handle Errors here.
            // const errorCode = error.code;
            // const errorMessage = error.message;
            // // The email of the user's account used.
            // const email = error.email;
            // // The AuthCredential type that was used.
            // const credential =
            //   GoogleAuthProvider.credentialFromError(error);
            // // ...
            console.log(error);
          });
      }}
    >
      {userContext.user ? 'Logout' : 'Login'}
    </Button>
  );
}

LoginButton.propTypes = {
  handleSnackbarOpen: PropTypes.func,
};

export default LoginButton;
